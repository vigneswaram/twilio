'use strict';
/*
 'use strict' is not required but helpful for turning syntactical errors into true errors in the program flow
 https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Strict_mode
*/

/* cfenv provides access to your Cloud Foundry environment
 for more info, see: https://www.npmjs.com/package/cfenv */
var cfenv = require('cfenv');
var util = require('util');
/* create a new express servers */
var twilio = require("twilio");
var twilioSid,twilioToken;

twilioSid ='ACd3ecd3dfa31ebc8ba4b838eb2a208e88';
twilioToken='6b2c87549516bcaaf4a2a56794ff114e';
var appEnv = cfenv.getAppEnv();

/*
 Once you 'require' a module you can reference the things that it exports.  These are defined in module.exports.

 For a controller in a127 (which this is) you should export the functions referenced in your Swagger document by name.

 Either:
  - The HTTP Verb of the corresponding operation (get, put, post, delete, etc)
  - Or the operationId associated with the operation in your Swagger document

  In the starter/skeleton project the 'get' operation on the '/sendMsg' path has an operationId named 'sendMsg'.  Here,
  we specify that in the exports of this module that 'sendMsg' maps to the function named 'sendMsg'
 */
module.exports = {
  hello: hello
};

/*
  Functions in a127 controllers used for operations should take two parameters:

  Param 1: a handle to the request object
  Param 2: a handle to the response object
 */
function hello(req, res) {
  // variables defined in the Swagger document can be referenced using req.swagger.params.{parameter_name}
  //var number = req.swagger.params.number.value || '+917032333901';
  var tktID = req.swagger.params.ticketId.value || 'abcd11234';
  //number = '+'+number;
  var hello = util.format('Success');
  //var hello = util.format('Hello, %s!', number);
  
  var client = require("twilio")(twilioSid,twilioToken);

	client.messages.create({ 
	to: '+94718623246', 
	from: '+12018857358', 
	body: "Hello , You recently booked an air line ticket " + tktID + ". We are offering baggage insurance for your trip please vistit Allianz app for policy details"
	},function(err, message){ 
	if(err)
	console.log(err);
	console.log(message.sid); 
	});

  // this sends back a JSON response which is a single string
  res.json(hello);
}
